
var flag = 1000;
var savBal = 1000;
var old_pass = "pass";
var new_pass;
var c_password;

var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; 
var yyyy = today.getFullYear();
today = mm + '/' + dd + '/' + yyyy;

document.getElementById("home-page").style.display = "none";
document.getElementById("print-page").style.display = "none";
document.getElementById("summary-page").style.display = "none";
document.getElementById("password-page").style.display = "none";
document.getElementById("login-page").style.display = "block";

if(c_password){
	new_pass = c_password;
}else{
	c_password = old_pass;
}

var logged_user;
	
function check(form)
{
	var p1 = document.getElementById("psw");
	var u1 = document.getElementById("user");

	if(u1.value == "ishav" || u1.value == "raj" && p1.value == c_password)
	{
	  alert("Login Successful");  
	  document.getElementById("home-page").style.display = "block";
	  document.getElementById("login-page").style.display = "none";
	  document.getElementById("logged_in_user").innerHTML = "welcome " +u1.value;
	  logged_user = u1.value;
	}
	else {
	  alert("Incorrect Username or Password");
	}
}


function transfer(){
	document.getElementById("home-page").style.display = "block";
	document.getElementById("print-page").style.display = "none";
	document.getElementById("summary-page").style.display = "none";
	document.getElementById("password-page").style.display = "none";
	document.getElementById("login-page").style.display = "none";
}

function print(){
	document.getElementById("home-page").style.display = "none";
	document.getElementById("print-page").style.display = "block";
	document.getElementById("summary-page").style.display = "none";
	document.getElementById("password-page").style.display = "none";
	document.getElementById("login-page").style.display = "none";	
}

function summary(){
	document.getElementById("home-page").style.display = "none";
	document.getElementById("print-page").style.display = "none";
	document.getElementById("summary-page").style.display = "block";
	document.getElementById("password-page").style.display = "none";
	document.getElementById("login-page").style.display = "none";
}

function password_page(){
	document.getElementById("home-page").style.display = "none";
	document.getElementById("print-page").style.display = "none";
	document.getElementById("summary-page").style.display = "none";
	document.getElementById("password-page").style.display = "block";
	document.getElementById("login-page").style.display = "none";	
}

function logout(){
	document.getElementById("home-page").style.display = "none";
	document.getElementById("print-page").style.display = "none";
	document.getElementById("summary-page").style.display = "none";
	document.getElementById("password-page").style.display = "none";
	document.getElementById("login-page").style.display = "block";
}


 function checkForm()
   {
    var oldP=document.getElementById("oldP").value;
    var newP=document.getElementById("newP").value;
    var confirmP =document.getElementById("confirmP").value;
	

    if(oldP!=""&&newP!=""&&confirmP!="")
    {
		if(oldP==c_password){
			  if(oldP!=newP)
			  {
				if(newP==confirmP)
				 {
					c_password = newP;
					alert("Password changed sucessfully!");
					var frm = document.getElementsByName('change_pwd_form')[0];
					frm.reset();
					return true;
				 }
				 else
				  {
					alert("Confirm password is not same as you new password.");
					return false;
				  }
			  }
			  else
			 {
			  alert(" This Is Your Old Password,Please Provide A New Password");
			  return false;
			 }
		}
		else{
			alert("You have entered wrong old password.");
		}
    }
    else
    {
     alert("All Fields Are Required");
     return false;
    }
}


document.getElementById("curBal").value = savBal;

function tranfer() {
    var fromAc = document.getElementById("fromAccount").value;
    var toAc = document.getElementById("toAccount").value;
    var amount = document.getElementById("amount").value;
	if (fromAc == toAc) {
        alert('Transfer not possible between same accounts!');
        return;
    }
	if(fromAc == "Checking" && toAc == "Saving") {
        if (flag >= amount) {
            savBal = (+savBal + +amount);
			flag = (+flag - +amount);
			alert('Transfer done!');
            addRecord(fromAc, today, 0, amount, flag, logged_user);
			addRecord(toAc, today, amount, 0, savBal, logged_user);
        } else {
            alert('Please enter valid amount.');
            return;
        }
    }
	if(fromAc == "Saving" && toAc == "Checking") {
        if (savBal >= amount) {

            savBal = +savBal - +amount;
            flag = +flag + +amount;
            addRecord(fromAc, today, 0, amount, savBal, logged_user);
			addRecord(toAc, today, amount, 0, flag, logged_user);

        } else {
            alert('Please enter valid amount.');
            return;
        }
    }
	if(fromAc == "Checking" && toAc == "Other"){
		if (flag >= amount) {
			flag = (+flag - +amount);
			alert('Transfer done!');
            addRecord(fromAc, today, 0, amount, flag, logged_user);
        } else {
            alert('Please enter valid amount.');
            return;
        }
	}
	if(fromAc == "Saving" && toAc == "Other"){
		if (savBal >= amount) {
            savBal = +savBal - +amount;
			alert('Transfer done!');
            addRecord(fromAc, today, 0, amount, savBal, logged_user);

        } else {
            alert('Please enter valid amount.');
            return;
        }
	}
   
    SelFrom();
}

function SelFrom() {
    var fromAc = document.getElementById("fromAccount").value;
	var toAc = document.getElementById("fromAccount").value;
    if (fromAc == "Checking") {
        document.getElementById("curBal").value = flag;
        document.getElementById("toAccount").value = 'Saving';
    }
    if (fromAc == "Saving") {
        document.getElementById("curBal").value = savBal;
        document.getElementById("toAccount").value = 'Checking';
    }
    document.getElementById("amount").value = '';
    document.getElementById("finalBalance").value = '';
}

function addRecord(from, date, deposit, withdraw, finalBal, cur_user) {
    var table = document.getElementById("listTransactions");
    var row = table.insertRow();


    var col1 = row.insertCell(0);
    var col2 = row.insertCell(1);
    var col3 = row.insertCell(2);
    var col4 = row.insertCell(3);
    var col5 = row.insertCell(4);

    col1.innerHTML = from;
    col2.innerHTML = date;
    col3.innerHTML = deposit;
    col4.innerHTML = withdraw;
    col5.innerHTML = finalBal;
}


function printdiv(printpage)
{
	var headstr = "<html><head><title></title></head><body>";
	var footstr = "</body>";
	var newstr = document.all.item(printpage).innerHTML;
	var oldstr = document.body.innerHTML;
	document.body.innerHTML = headstr+newstr+footstr;
	window.print();
	document.body.innerHTML = oldstr;
	return false;
}

