-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 15, 2018 at 05:52 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `MealApp`
--

-- --------------------------------------------------------

--
-- Table structure for table `coupan`
--

CREATE TABLE `coupan` (
  `id` int(20) NOT NULL,
  `coupan` varchar(20) COLLATE utf8_bin NOT NULL,
  `discount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `coupan`
--

INSERT INTO `coupan` (`id`, `coupan`, `discount`) VALUES
(1, 'HAR50', 50),
(2, 'MAN50', 50),
(3, 'NAK30', 30),
(4, 'ISH20', 20);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(20) NOT NULL,
  `userId` int(11) NOT NULL,
  `numMem` int(20) NOT NULL,
  `mealOptn` varchar(55) COLLATE utf8_bin NOT NULL,
  `menuOptn` varchar(55) COLLATE utf8_bin NOT NULL,
  `instruction` varchar(255) COLLATE utf8_bin NOT NULL,
  `bill` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `userId`, `numMem`, `mealOptn`, `menuOptn`, `instruction`, `bill`) VALUES
(8, 1, 0, 'breakfast', 'both', '', 0),
(9, 1, 8, 'breakfast', 'nonV', '', 0),
(10, 1, 90, 'breakfast', 'both', '', 0),
(11, 1, 9, 'breakfast', 'nonV', '', 90),
(12, 1, 0, 'breakfast', 'nonV', '', 0),
(13, 1, 0, 'dinner', 'nonV', '', 0),
(14, 1, 7, 'breakfast', 'nonV', '', 70),
(15, 1, 7, 'breakfast', 'nonV', '', 70),
(16, 1, 6, 'breakfast', 'nonV', '', 60),
(17, 1, 7, 'breakfast', 'nonV', '', 70),
(18, 1, 7, 'breakfast', 'nonV', '', 70),
(19, 1, 9, 'breakfast', 'both', '', 135),
(20, 1, 9, 'breakfast', 'nonV', '', 90),
(21, 1, 8, 'breakfast', 'nonV', '', 80),
(22, 1, 9, 'breakfast', 'Veg', '', 45),
(23, 1, 4, 'breakfast', 'both', '', 60),
(24, 1, 2, 'breakfast', 'Veg', '', 10),
(25, 1, 67, 'breakfast', 'both', '', 1005),
(26, 1, 2, 'breakfast', 'nonV', '', 20),
(27, 1, 5, 'breakfast', 'Veg', 'yu', 25),
(28, 1, 3, 'breakfast', 'nonV', 'ee', 30),
(29, 1, 0, 'breakfast', '', '', 0),
(30, 1, 3, 'breakfast', 'nonV', 'rr', 30),
(31, 1, 0, 'breakfast', '', '', 0),
(32, 1, 2, 'breakfast', 'nonV', '4', 20),
(33, 1, 0, 'breakfast', '', '', 0),
(34, 1, 0, 'breakfast', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(20) NOT NULL,
  `userId` int(11) NOT NULL,
  `creditNumber` int(11) NOT NULL,
  `creditCardName` varchar(30) COLLATE utf8_bin NOT NULL,
  `date` date NOT NULL,
  `cvc` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `userId`, `creditNumber`, `creditCardName`, `date`, `cvc`) VALUES
(18, 1, 234567, 'credit', '2019-01-12', 567),
(19, 1, 34567, 'debit', '2019-02-14', 456),
(20, 1, 0, '', '0000-00-00', 0),
(21, 1, 45678, 'credit', '2019-02-07', 879),
(22, 1, 0, '', '0000-00-00', 0),
(23, 1, 45678, 'credit', '2019-01-10', 444),
(24, 1, 657, '', '0000-00-00', 0),
(25, 1, 0, '', '0000-00-00', 0),
(26, 1, 0, '', '0000-00-00', 0),
(27, 1, 0, '', '0000-00-00', 0),
(28, 1, 0, '', '0000-00-00', 0),
(29, 1, 0, '', '0000-00-00', 0),
(30, 1, 0, '', '0000-00-00', 0),
(31, 1, 0, '', '0000-00-00', 0),
(32, 1, 0, '', '0000-00-00', 0),
(33, 1, 0, '', '0000-00-00', 0),
(34, 1, 0, '', '0000-00-00', 0),
(35, 1, 0, '', '0000-00-00', 0),
(36, 1, 0, '', '0000-00-00', 0),
(37, 1, 0, '', '0000-00-00', 0),
(38, 1, 0, '', '0000-00-00', 0),
(39, 1, 0, '', '0000-00-00', 0),
(40, 1, 0, '', '0000-00-00', 0),
(41, 1, 76886, 'rt', '2018-10-24', 876),
(42, 1, 353, 'dgd', '2018-10-17', 342),
(43, 1, 0, '', '0000-00-00', 0),
(44, 1, 24234242, 'fsdgrf', '0000-00-00', 343),
(45, 1, 0, '', '0000-00-00', 0),
(46, 1, 342424, '234234', '0000-00-00', 344),
(47, 1, 0, '', '0000-00-00', 0),
(48, 1, 0, '', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8_bin NOT NULL,
  `password` varchar(20) COLLATE utf8_bin NOT NULL,
  `email` varchar(30) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `password`, `email`) VALUES
(1, 'gabbar', 'sidhu', 'gabbar@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coupan`
--
ALTER TABLE `coupan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD UNIQUE KEY `unique` (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coupan`
--
ALTER TABLE `coupan`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
