
<html>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="myJs.js"></script>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "MealApp";

$conn = new mysqli($servername, $username, $password, $database);


if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

?>
