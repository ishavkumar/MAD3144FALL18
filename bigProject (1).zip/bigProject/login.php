<?php include "db.php";
  session_start();
 ?>
<html>
<head>
  <title> Log In </title>
  <link rel="stylesheet" href="css.css">
</head>
<body>
  <div class="background"></div>
  <div class="form-container" id="form">
    <div class="form-content">
      <div class="form-header">
        <img src="2.png" class="avatar">
        </div>
      </div>

  <h2> LOG IN </h2>
  <form method="post" action="" class="form">
    <div class="input-container">
       <input type="text" class="input" name="userName" id="userId" placeholder="Enter Username" required />
    </div>
    <div class="input-container">
     <input type="text" class="input" name="password" id="userId" placeholder="Enter Password" required />
    </div>
    <input type="submit" name="logIn" value="Log In" class="button"/>
      <button type="button" name="rgister" class="button" onclick="window.location.href='register.php'">Register </button>

  </form>
  </div>

</body>
</html>

<?php
if(isset($_POST["logIn"]))
{
  $name = $_POST["userName"];
  $password = $_POST["password"];
  $sql = "SELECT * FROM register where name = '$name' && password = '$password'";

  $result = $conn->query($sql);

   if ($result->num_rows > 0)
   {
    while($row = $result->fetch_assoc())
    {
        $_SESSION["id"] = $row['id'];
        $_SESSION['name'] = $row['name'];
        header("location: main.php");
    }
  }
  else
  {
    echo "Wrong username or password";
  }

}
if(isset($_POST["Register"]))
{
  header("location: register.php");
}
?>
