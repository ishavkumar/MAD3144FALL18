<?php include "db.php";
session_start();
?>
<html>
<head>
  <title> Book Table </title>
 <link rel="stylesheet" href="css.css">
</head>
<body>
  <div class="background"></div>
  <div class="form-container" id="form">
    <div class="form-content">
      <div class="form-header">
        <img src="2.png" class="avatar">
        </div>
      </div>
  <h1> Welcome <?php echo $_SESSION['name'];?></h1>
<form method="post" action="">

<div class = "main">
  <h2>  Book Your Table</h2>

  <input type="number" name="mnum" class="total_persons" id="input" placeholder="Enter the number of persons"/><br>
  Select Meal:<select name="meal">
    <option value="breakfast">Breakfast</option>
    <option value="lunch">Lunch</option>
    <option value="dinner">Dinner</option>
  </select>
<br>
  <input type="button" class="proceed_to_menu" name="confirmTable" id="button" value="Proceed"/>
  <button type="button" onclick="window.location.href='login.php'" id="button"/> Log Out </button>
</div>
<div class="menu">
  <input type="radio" name="menu" value="Veg"> Vegetarian<br>
  <input type="radio" name="menu" value="nonV"> Non-Vegetarian<br>
  <input type="radio" name="menu" value="both"> Both <br>
  Special instruction:<br>
  <input type="text" name="instruction"/><br>
  <input type="button" name="confirmMeal" class="proceed_to_billing" value="Proceed" id="button"/>
  <button type="button" onclick="window.location.href='main.php'" id="button"/> Cancel </button>
  <button type="button" onclick="window.location.href='login.php'" id="button"/> Log Out </button>
</div>
<div class="billing">
   <input type="text" name="coupan" id="input" placeholder="Enter coupan"/><br>
   <input type="number" id="bill_amount" class="input" placeholder="Total Bill" name="bill" readonly/><br>
  Payment Option:
  <div class="dropdown">
    <select name="payment_method" id="showHide">
      <option>choose payment type</option>
      <option value="credit"> Credit Card</option>
      <option value="debit"> Debit Card</option>
    </select>
    <div class="credit">
      Credit Card Number: <input type="number" class="credit_number" id="input" name="ccNum"/><br>
      Credit Card Name : <input type="text" class="credit_name" id="input" name="ccName"/><br>
      Expiry Date : <input type="date" class="credit_date" id="input" name="ccDate"/><br>
      CVC : <input type="number" name="ccvc" id="input"/><br>
    </div>
    <div class="debit">
      Debit Card Number: <input type="number" class="debit_number" id="input" name="ddNum"/><br>
      Debit Card Name : <input type="text" class="debit_name" id="input" name="ddName"/><br>
      Expiry Date : <input type="date" class="credit_date" id="input" name="ddDate"/><br>
      CVC : <input type="number" name="cvc" id="input"/><br>
    </div>
  </div>
  <br>
  <input type="submit" name="submit" value="Confirm" id="button"/>
  <input type="button" name="cancel" value="Cancel" id="button"/><br>

  <button type="button" onclick="window.location.href='login.php'" id="button"/> Log Out </button>
</div>
</div>

</form>
</body>
</html>

<?php
$bill = 0;
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
  if (empty($_POST["mnum"]))
  {
    $nameErr = "Name is required";
  }
}
if(isset($_POST["submit"]))
{
  $userId = $_SESSION['id'];
  $person = $_POST['mnum'];
  $meal = $_POST['meal'];
  $menu = $_POST['menu'];
  $sInstruction = $_POST['instruction'];
  $coupan = $_POST['coupan'];
  $creditNo = $_POST['ccNum'];
  $creditName = $_POST['ccName'];
  $ccDate = $_POST['ccDate'];
  $ccvc = $_POST['ccvc'];
  $debitNo = $_POST['ddNum'];
  $debitName = $_POST['ddName'];
  $ddDate = $_POST['ddDate'];
  $cvc = $_POST['cvc'];



  if($menu =="Veg"){
    $bill = $person*5;
  }elseif ($menu == "nonV") {
    $bill = $person*10;
  }elseif ($menu == "both") {
    $bill = $person*15;
  }

  $sql = "INSERT INTO `order` (`userId`, `numMem`, `mealOptn`, `menuOptn`, `instruction`, `bill`) VALUES ('$userId', '$person', '$meal', '$menu', '$sInstruction','$bill')";
  mysqli_query($conn,$sql);
  $order_id = $conn->insert_id;
  $_SESSION['order_id'] = $order_id;

  if($creditNo != ""){
    $sql_credit = "INSERT INTO `payment` (`userId`, `creditCardName`, `creditNumber`, `date`, `cvc`) VALUES ('$userId', '$creditName', '$creditNo', '$ccDate', '$ccvc')";
    mysqli_query($conn,$sql_credit);
  }else{
    $sql_debit = "INSERT INTO `payment` (`userId`, `creditCardName`, `creditNumber`, `date`, `cvc`) VALUES ('$userId', '$debitName', '$debitNo', '$ddDate', '$cvc')";
    mysqli_query($conn,$sql_debit);
  }

  header("location: receipt.php");
}


?>
