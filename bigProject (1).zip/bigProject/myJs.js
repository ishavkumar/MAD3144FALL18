$(document).ready(function()
{
  $(".main").show();
  $(".menu").hide();
  $(".billing").hide();
  $('.credit').hide();
  $('.debit').hide();

  $(".proceed_to_menu").click(function ()
  {
    $(".main").hide();
    $(".menu").show();
    $(".billing").hide();
  });

  $(".proceed_to_billing").click(function ()
  {
    $(".main").hide();
    $(".menu").hide();
    $(".billing").show();
    var bill = 0;
    var meal = $('input[name="menu"]:checked').val();
    var person = $('.total_persons').val();

    if(meal =="Veg"){
      bill = person * 5;
    }else if (meal == "nonV") {
      bill = person*10;
    }else if (meal == "both") {
      bill = person*15;
    }
    $('#bill_amount').val(bill);
  });

  $('#showHide').change(function()
  {
    if($(this).val() == "credit"){
      $('.credit').show();
      $('.debit').hide();
    }else if ($(this).val() == "debit") {
      $('.debit').show();
      $('.credit').hide();
    }
    });



});
