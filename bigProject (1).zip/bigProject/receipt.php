<?php include "db.php";
session_start();
$order_id = $_SESSION['order_id'];
$sql = "SELECT * FROM `order` where `id` = '$order_id' ";
$result = $conn->query($sql);

 if ($result->num_rows > 0)
 {
  while($row = $result->fetch_assoc())
  {
      $num_of_persons = $row['numMem'];
      $instruction = $row['instruction'];
      $bill = $row['bill'];
  }
}
else
{
  echo "No order exists";
}

?>
<html>
<head>
  <title> Receipt </title>
  <link rel="stylesheet" href="css.css">
</head>
<body>
  <div class="background"></div>
  <div class="form-container" id="form">
    <div class="form-content">
      <div class="form-header">
        <img src="2.png" class="avatar">
        </div>
      </div>
<h2> Receipt </h2>
<form method="post" action="">
Number of Persons: <input type="number" name="tableNo" placeholder="number of persons" value="<?php echo $num_of_persons ?>" readonly/><br>
Special Instructions: <input type="text" name="specialInstructions" placeholder="special instruction" value="<?php echo $instruction ?>" readonly/><br>
Total Bill: <input type="number" name="Rbill" placeholder="Bill" value="<?php echo $bill ?>" readonly/><br>
<button type="button" name="back" onclick="window.location.href='main.php'" id="button"/> Back

</form>
</div>
</div>
</body>
</html>
<?php
if(isset($_POST["backButton"]))
{
  header("location: main.php");
}

?>
