<?php include "db.php"; ?>
<html>
<head>
  <title>Register</title>
  <link rel="stylesheet" href="css.css">

</head>
<body>
  <div class="background"></div>
  <div class="form-container" id="form">
    <div class="form-content">
      <div class="form-header">
        <img src="2.png" class="avatar">
        </div>
      </div>
        <h2> Register </h2>
          <form method="post" action="" class="form">
            <div class="input-container">
               <input type="text" class="input" name="userName" id="userId" placeholder="Enter Username" required />
            </div>

          <div class="input-container">
            <input type="password" class="input" name="password" placeholder="Enter Password" required/>
        </div>
        <div class="input-container">
            <input type="text" class="input" name="Email" placeholder="Enter E-mail" required/>
        </div>
          <input type="submit" name ="Register" value = "Sign Up" class="button"/>
          <button type="button" name="back" onclick="window.location.href='login.php'" class="button"/> Log In
        </form>
      </div>
    </div>

</body>
</html>


<?php
if(isset($_POST["Register"]))
{
  $name = $_POST["userName"];
  $password = $_POST["password"];
  $email = $_POST["Email"];
  mysqli_query($conn,"INSERT INTO register (`name`,`password`,`creditCard`) VALUES ('$name', '$password', '$email')");
  header("location: login.php");
}

if(isset($_POST["back"]))
{
  header("location: login.php");
}

?>
