function check(form)
{
var u1 = document.getElementById("user");
var p1 = document.getElementById("psw");

if(u1.value == "Ishav" && p1.value == "pass")
{
  alert("ok");
  return true;
}
else {
  alert("not ok");
  return false;
}
}
